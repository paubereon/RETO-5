package com.actividad.appproductos.Adaptadores;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.actividad.appproductos.Modelos.Producto;
import com.actividad.appproductos.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class AdaptadorProducto extends RecyclerView.Adapter<AdaptadorProducto.ViewHolder>{

    private Context mContext;
    private ArrayList<Producto> mProductos;

    public AdaptadorProducto(Context mContext, ArrayList<Producto> mProductos) {
        this.mContext = mContext;
        this.mProductos = mProductos;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        return new ViewHolder(view);
    }

    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Producto producto = mProductos.get(position);
        holder.txt_titulo.setText(producto.getTitulo());
        holder.txt_funcion.setText(producto.getFuncion());
        holder.txt_descripcion.setText(producto.getDescripcion());
        holder.txt_precio.setText(producto.getPrecio().toString());

        Picasso.get().load(producto.getImagen()).into(holder.img_ingrediente);

        holder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener la URL relacionada del producto
                String url = producto.getUrl();
                // Crear un intent para abrir la URL en un navegador
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mProductos.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView img_ingrediente;
        TextView txt_titulo;
        TextView txt_funcion;
        TextView txt_descripcion;
        TextView txt_precio;
        Button btn;

        public ViewHolder(View itemView) {
            super(itemView);
            img_ingrediente = itemView.findViewById(R.id.Imagen);
            txt_titulo = itemView.findViewById(R.id.txtTitulo);
            txt_funcion = itemView.findViewById(R.id.txtFuncion);
            txt_descripcion = itemView.findViewById(R.id.txtDescripcion);
            txt_precio = itemView.findViewById(R.id.txtPrecio);

            btn = itemView.findViewById(R.id.button);
        }
    }
}
