package com.actividad.appproductos;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.actividad.appproductos.Adaptadores.AdaptadorProducto;
import com.actividad.appproductos.Modelos.Producto;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AdaptadorProducto adaptadorProducto;
    private ArrayList<Producto> listaProductos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.RecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        listaProductos = new ArrayList<>();
        // Añadir datos
        listaProductos.add(new Producto("¿QUÉ ES? Doritos es una marca de tortilla chip con sabor producidos desde 1964 por la empresa de alimentos estadounidense Frito-Lay. El aperitivo es el tradicional totopo mexicano condimentado, está hecho de tortilla de maíz frita, su forma triangular proviene de la original derivada de rebanar las tortillas.", "¿PARA QUÉ SIRVE?  Sirve para aumentar la probabilidad de reacción alérgica en pacientes susceptibles a rinitis, asma o erupciones en la piel.", "Doritos",
                "https://www.doritos.com/es", "https://ecommerce.surtifamiliar.com/backend/admin/backend/web/archivosDelCliente/items/images/Pasabocas-Pasabocas-Surtidos-PASABDORITOS-x185g-MEGA-QUESO-FLIAR-527620201120112514.jpg",
                1000.0));
        listaProductos.add(new Producto("¿QUÉ ES? Coca-Cola es una bebida azucarada gaseosa vendida a nivel mundial en tiendas, restaurantes y máquinas expendedoras en más de doscientos países o territorios.", "¿PARA QUÉ SIRVE? Te mantiene despierto, concentrando y alerta. Algunos estudios incluso aseguran que puede mejorar la memoria y el funcionamiento del corazón.", "Coca-Cola",
                "https://www.entuhogar.coca-cola.com.co/productos", "https://lavaquita.co/cdn/shop/products/supermercados_la_vaquita_supervaquita_gaseosa_coca_cola_10_oz_bebidas_liquidas_1024x1024.jpg?v=1620489361",
                2000.0));
        listaProductos.add(new Producto("¿QUÉ ES? Es una bebida alcohólica y espirituosa obtenida por la destilación de la malta fermentada de cereales como cebada, trigo, centeno y maíz, y su posterior añejamiento en barriles de madera, tradicionalmente de roble blanco. Además Johnnie Walker, se convirtió en una de las marcas de whisky más icónicas y reconocidas en todo el mundo.", "¿PARA QUE SIRVE? Debido a que beber whisky con moderación ayuda a mejorar la circulación sanguínea, mejorará la oxigenación corporal, lo cual tendría una sensación de relajación en el cuerpo y de esta forma, el whisky ayudaría a reducir el estrés, los niveles de ansiedad y los nervios.", "Whisky Johhnie Wolker",
                "https://www.exito.com/whisky-johnnie-walker-blue-label-mini-cube-750-ml-920359/p", "https://media.diageocms.com/media/20lbzkwy/johnnie-walker-blue-label-bottle-split-with-media.jpg",
                600000.0));

        listaProductos.add(new Producto("¿QUÉ ES? Colorear una imagen es el proceso de añadir color a un dibujo o ilustración en blanco y negro para hacerlo más vibrante y realista", "¿PARA QUÉ SIRVE? Colorear es una forma sana de aliviar el estrés, porque calma el cerebro y ayuda a que el cuerpo se relaje.", "MI IMAGEN",
                "https://github.com/paubereon/RETO-5/blob/main/IMAGEN%20PAULA.jpg", "https://github.com/paubereon/RETO-5/blob/main/IMAGEN%20PAULA.jpg",
                3000.0));

        adaptadorProducto = new AdaptadorProducto(this, listaProductos);
        recyclerView.setAdapter(adaptadorProducto);
    }
}