package com.actividad.appproductos.Modelos;

public class Producto {

    String Funcion, Descripcion, Titulo, Url, Imagen;
    Double Precio;

    public Producto(String funcion, String descripcion, String titulo, String url, String imagen, Double precio) {
        Funcion = funcion;
        Descripcion = descripcion;
        Titulo = titulo;
        Url = url;
        Imagen = imagen;
        Precio = precio;
    }

    public String getFuncion() {
        return Funcion;
    }

    public void setFuncion(String funcion) {
        Funcion = funcion;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String titulo) {
        Titulo = titulo;
    }

    public String getUrl() {
        return Url;
    }

    public void setUrl(String url) {
        Url = url;
    }

    public String getImagen() {
        return Imagen;
    }

    public void setImagen(String imagen) {
        Imagen = imagen;
    }

    public Double getPrecio() {
        return Precio;
    }

    public void setPrecio(Double precio) {
        Precio = precio;
    }
}
